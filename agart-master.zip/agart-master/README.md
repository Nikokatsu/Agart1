agar5
=============
Links (all servers located in Europe):

https://agar5.herokuapp.com

https://agar5-beta.herokuapp.com (beta version, automatic deploys)

https://agar5-lenny.herokuapp.com (Le Lenny Clan server)

Create a new server
---
[![Deploy to Heroku](http://www.herokucdn.com/deploy/button.png)](https://heroku.com/deploy)
